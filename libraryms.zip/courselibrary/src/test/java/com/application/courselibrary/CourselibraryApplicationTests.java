package com.application.courselibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourselibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
